#!/bin/bash

##SBATCH -N 1
#SBATCH -C cpu
#SBATCH -q shared
#SBATCH -J UEDGE_wall_Li
#SBATCH --mail-user=islam9@llnl.gov
#SBATCH --mail-type=ALL
#SBATCH -t 48:00:0  
#SBATCH -n 1
#SBATCH -c 2              
#SBATCH --output=output.log  
#SBATCH --error=error.log    
module load python/3.10

srun --cpu-bind=cores python3 coupling_UEDGE_heat.py
